<?php
$user=Auth::user();
?>
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow fuchsia">

    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>

    <!-- Topbar Search -->
    <form
        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
        <div class="input-group">
            <h6 id="greetingTime" style="font-family: Arial Black;"></h6>
        </div>
    </form>

    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">

        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
        

        <!-- Nav Item - Alerts -->
        

        <div class="topbar-divider d-none d-sm-block"></div>

        <!-- Nav Item - User Information -->
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-dark "><?php echo e($user->name); ?></span>
                <img class="img-profile rounded-circle"
                    src="<?php echo e(asset('dashboard/img/undraw_profile.svg')); ?>">
            </a>
            <!-- Dropdown - User Information -->
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="userDropdown">
                
                
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                    Logout
                </a>
            </div>
        </li>

    </ul>

</nav>

<script>
    function updateTime() {
        const now = new Date();
        const hours = now.getHours();
        const minutes = now.getMinutes();
        const seconds = now.getSeconds();

        // Convert to 12-hour format
        const period = hours >= 12 ? 'PM' : 'AM';
        const formattedHours = hours % 12 || 12; // Converts 0 to 12
        const formattedMinutes = String(minutes).padStart(2, '0');
        const formattedSeconds = String(seconds).padStart(2, '0');

        // Display time
        const currentTime = `${formattedHours}:${formattedMinutes}:${formattedSeconds} ${period}`;

        // Determine greeting
        let greeting;
        if (hours >= 0 && hours < 12) {
            greeting = 'Good Morning';
        } else if (hours >= 12 && hours < 15) {
            greeting = 'Good Afternoon';
        } else {
            greeting = 'Good Evening';
        }

        // Update the single h6 tag
        document.getElementById('greetingTime').textContent = `${greeting} - ${currentTime}`;
    }

    // Update time every second
    setInterval(updateTime, 1000);
    updateTime(); // Initial call
</script><?php /**PATH C:\xampp\htdocs\insurance\resources\views/dashboard/include/navbar.blade.php ENDPATH**/ ?>