
<?php $__env->startSection('title', 'User List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="text-right">
        <button class="btn btn-danger mr-2 mb-2" onclick="window.history.back()"><i class="fa fa-arrow-left" aria-hidden="true"></i></button>
        <button class="btn btn-warning mr-2 mb-2" onclick="window.location.reload()"><i class="fa fa-spinner" aria-hidden="true"></i></button>
        <?php if(count($logos)==0): ?>
        <a href="<?php echo e(route('logo')); ?>" class="btn btn-primary mr-2 mb-2" ><i class="fa fa-user-plus" aria-hidden="true"></i></a>
        <?php endif; ?>
    </div>
    <div class="card">
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
        <div class="card-header">

            <h4>Company Info List</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped text-center" id="user-list">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Company Name</th>
                            <th>Company Email address</th>
                            <th>Contact Number</th>
                            <th>Place</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($logo->name); ?></td>
                            <td><?php echo e($logo->email); ?></td>
                            <td><?php echo e($logo->phone); ?></td>
                            <td><?php echo e($logo->place); ?></td>
                            <td><img src="<?php echo e(asset('storage/' . $logo->logo)); ?>" alt="Ration card Image" class="img-fluid mb-2" style="max-width: 200px;"></td>    
                            <td>
                                <a href="<?php echo e(route('logo.edit', $logo->id)); ?>" class="btn btn-primary "><i class="fas fa-fw fa-pencil-alt"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-right">
                    <?php echo e($logos->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insurance\resources\views/dashboard/logo/index.blade.php ENDPATH**/ ?>