
<?php $__env->startSection('title', 'Password Reset List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="text-right">
        <button class="btn btn-danger mr-2 mb-2" onclick="window.history.back()"><i class="fa fa-arrow-left" aria-hidden="true"></i></button>
        <button class="btn btn-warning mr-2 mb-2" onclick="window.location.reload()"><i class="fa fa-spinner" aria-hidden="true"></i></button>
    </div>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4>Pending Password Reset List</h4>
            <a href="<?php echo e(route('all.password.reset.request')); ?>" class="btn btn-primary">Show All Request <i class="fa fa-list-ul" aria-hidden="true"></i></a>
        </div>
        
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped text-center" id="request-list">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Request Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($requests->isEmpty()): ?>
                            <tr>
                                <td colspan="4" class="text-center">No password reset requests found.</td>
                            </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($request->user_name); ?></td>
                                <td><?php echo e($request->request_date); ?></td>
                                <td>
                                    <a href="<?php echo e(route('password.reset.edit', $request->id)); ?>" class="btn btn-primary "><i class="fas fa-fw fa-pencil-alt"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-right">
                    <?php echo e($requests->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insurance\resources\views/dashboard/password-reset/index.blade.php ENDPATH**/ ?>