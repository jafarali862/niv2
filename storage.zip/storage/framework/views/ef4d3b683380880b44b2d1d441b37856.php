

<?php $__env->startSection('title', 'Odometer List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="text-right">
        <button class="btn btn-danger mr-2 mb-2" onclick="window.history.back()"><i class="fa fa-arrow-left"
                aria-hidden="true"></i></button>
        <button class="btn btn-warning mr-2 mb-2" onclick="window.location.reload()"><i class="fa fa-spinner"
                aria-hidden="true"></i></button>
    </div>
    <h1 class="h3 mb-4 text-gray-800">Odometer List</h1>
    
    <div class="table-responsive">
        <table class="table table-bordered table-hover text-center">
            <thead class="thead-light">
                <tr>
                    <th>S.No</th>
                    <th>Name</th>
                    <th>Check In Time</th>
                    <th>Check Out Time</th>
                    <th>Date</th>
                    <th>View</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $odometerRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($odometerRecords->firstItem() + $index); ?></td>
                    <td><?php echo e($record->user_name); ?></td> 
                    <td><?php echo e($record->check_in_time); ?></td>
                    <td>
                        <?php if($record->check_out_time): ?>
                            <?php echo e($record->check_out_time); ?>

                        <?php else: ?>
                            <span class="text-danger">Exec not closed</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($record->check_out_date): ?>
                            <?php echo e($record->check_out_date); ?>

                        <?php else: ?>
                            <span class="text-danger">Exec not closed</span>
                        <?php endif; ?>
                    </td>
                    <td><a href="<?php echo e(route('odometer.view', $record->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>            
        
        </table>
    </div>

    <!-- Pagination Links -->
    <div class="d-flex justify-content-between">
        <div>
            Showing <?php echo e($odometerRecords->firstItem()); ?> to <?php echo e($odometerRecords->lastItem()); ?> of <?php echo e($odometerRecords->total()); ?> records
        </div>
        <div>
            <?php echo e($odometerRecords->links()); ?> 
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insurance\resources\views/dashboard/odometer/index.blade.php ENDPATH**/ ?>